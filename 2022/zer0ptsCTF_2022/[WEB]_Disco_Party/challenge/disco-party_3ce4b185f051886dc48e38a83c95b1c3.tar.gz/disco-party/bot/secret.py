# Secret discord channel ID
LOGGING_CHANNEL_ID = 1337
# Secret discord server
DISCORD_SECRET = "XXXXYYYYZZZZ"
