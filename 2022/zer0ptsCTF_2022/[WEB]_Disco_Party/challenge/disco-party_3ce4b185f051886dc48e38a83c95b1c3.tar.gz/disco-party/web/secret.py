FLAG = "fak3pts{*** REDUCTED ***}"

# Secret key
APP_KEY = "*** REDUCTED ***"

# reCAPTCHA key (Set none for local test)
RECAPTCHA_SECRET = None
