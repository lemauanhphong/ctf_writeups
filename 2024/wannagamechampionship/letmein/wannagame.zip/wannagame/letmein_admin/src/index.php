<?php

if (!isset($_GET['order'])) 
{
    header("Location: /?order=ASC");
    die();
}


$servername = getenv('DB_HOST');
$username = getenv('DB_USER');
$password = getenv('DB_PASSWORD');
$dbname = getenv('DB_NAME');


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


$sql = "SELECT role, COUNT(*) as count FROM users GROUP BY role";
$result = $conn->query($sql);


$adminCount = 0;
$userCount = 0;


if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if ($row['role'] == 'admin') {
            $adminCount = $row['count'];
        } elseif ($row['role'] == 'user') {
            $userCount = $row['count'];
        }
    }
}


$order = $_GET["order"];
$sqlUsers = "SELECT email, role FROM users ORDER BY email $order";
$resultUsers = $conn->query($sqlUsers);


$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Count</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
<div class="container mt-5">
    <h1>User Counts</h1>
    <div class="row">
        <div class="col-md-6">
            <div class="card text-white bg-primary mb-3">
                <div class="card-header">Admin Count</div>
                <div class="card-body">
                    <h5 class="card-title"><?php echo $adminCount; ?></h5>
                    <p class="card-text">Total number of admins.</p>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card text-white bg-success mb-3">
                <div class="card-header">User Count</div>
                <div class="card-body">
                    <h5 class="card-title"><?php echo $userCount; ?></h5>
                    <p class="card-text">Total number of users.</p>
                </div>
            </div>
        </div>
    </div>

    <h2 class="mt-5">User List</h2>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Email</th>
                <th>Role</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($resultUsers->num_rows > 0): ?>
                <?php while ($user = $resultUsers->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                        <td><?php echo htmlspecialchars($user['role']); ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="2">No users found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>
