#!/usr/bin/env bash
echo SECRET_KEY_BASE=`dd if=/dev/random bs=128 count=1 2>/dev/null | od -An -tx1 | tr -d ' \t\n'` > .SECRET_KEY_BASE.env
docker compose up --build