class AddUsers < ActiveRecord::Migration[7.1]
  def change
    users = [
      {
        'email' => "redgirl2808@email.com",
        "password" => "ilovered",
        "role" => "user"
      },
      {
        'email' => "wannagame@email.com",
        "password" => "thisiswannagameaccount",
        "role" => "user"
      },
      {
        'email' => ENV.fetch('ADMIN_EMAIL'),
        "password" => ENV.fetch('ADMIN_PASSWORD'),
        "role" => "admin"
      },
      {
        'email' => "agentp@email.com",
        "password" => "perrytheplatypus",
        "role" => "user"
      },
      {
        'email' => "dev@email.com",
        "password" => "test123",
        "role" => "user"
      }
    ]

    users.each { 
      |user| User.create!(
        email: user['email'],
        password: user['password'],
        password_confirmation: user['password'],
        role: user['role']
      ) 
    }
  end
end
