module GetflagHelper
end
