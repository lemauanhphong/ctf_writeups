class GetflagController < ApplicationController
    def get
        if current_user.role == 'admin'
            render plain: `/readflag`
        else
            render plain: "Admin only"
        end
        
    end
end
