require 'base64'

class FileController < ApplicationController
    def download
        file = params[:img]

        if file.start_with?("..")
            file = "1.webp"
        end
        
        send_data Base64.encode64(File.read("#{Rails.root}/public/" + file))
    end
end
