#include <stdio.h>

int main()
{
    FILE *fptr;
    fptr = fopen("/flag", "r");

    char flag[100];
    fgets(flag, 100, fptr); 

    puts(flag);

    fclose(fptr);
    return 0;
}